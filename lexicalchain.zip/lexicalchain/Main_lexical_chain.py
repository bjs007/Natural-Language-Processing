from wordData import *
from textblob import TextBlob
from helper_function import *
import copy
import ConfigParser
Config = ConfigParser.ConfigParser()
Config.read("config.ini")
activate_multilevel_wordonomy_transition =\
	Config.getboolean("SectionOne", "activate_multilevel_wordonomy_transition")
test_file = open('test_data.bin', 'r')
helper = helper_function()
delimiter = "\n" 
paralist =\
	test_file.read().split(delimiter) 
test_file.close() 
word_dict = dict()
lexical_chain_dict = dict() 
word_list = [] 


def clearing_global_variable():
        global word_list
	word_dict.clear()
	lexical_chain_dict.clear()
	word_list = []

def _lexical_chain_formation(wordc, wordl):
        wd = str(wordl[0])
	word_list =  [wordl[0]]
	_chain_dict = {wd: word_list} 
	while len(wordl) != 0: 
		list_of_lexical_chain = []
		if wordl[0] not in _chain_dict: 
			
			element_rship =_compare(str(wordl[0]),_chain_dict)
			if element_rship:
				list_of_lexical_chain.append(wordl[0])
			
			else:
				_chain_dict[str(wordl[0])] = [wordl[0]]
		
		wordl.pop(0)
	
	disp_chain(_chain_dict)

def disp_chain(chain_dict):
	number_of_chain = 1
	for key in chain_dict:
		print ("Chain " + str(number_of_chain) +":\t"),
		for word_chain in chain_dict[key]: # Iterate over lexical chain dictionary
			if word_chain in word_list: # check if word in global word dict
				print (word_chain + "(" +
					   str(word_list.count(word_chain)) + ")"),
				if word is not\
						word_chain[-1]:
						print (", "),
		print
		number_of_chain += 1
	print '-------------------------------------------------------------'
	
def _compare(word, lexical_chain_dict):
	flag = helper._assertion(word,
							 lexical_chain_dict,
							 wordc,
							 activate_multilevel_wordonomy_transition)
	return flag





for p in paralist:
	wordl = []
	blob = TextBlob(p)
	wordlist = []
        wordlist = blob.tags
	for (word,i) in wordlist:
            if (i=='NN') or (i=='NNS'):
                wordl.append(word.lower())
		for word in wordl: 
			if word not in word_dict:
				word_dict[word] = wordData(word)
			else:
				noun_data = word_dict[word]
				noun_data.increase_count_value()
	wordc = word_dict.copy() 
	word_list = copy.copy(wordl)
	_lexical_chain_formation(wordc, wordl) 
	clearing_global_variable() 
